﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LiteralControl imageGallery = new LiteralControl();

            var labelSwitch = @"<label class='switch><input type='checkbox' id='chkl10'><span class='slider round'></span></label>";
            
            imageGallery.Text = "<ul><li>Level 0 "+ labelSwitch +"</li></ul>";

            //this.dynamicCtrl.Controls.Add(imageGallery);
        }
    }
}