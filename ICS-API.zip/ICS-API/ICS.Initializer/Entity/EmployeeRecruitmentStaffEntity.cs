﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICS.Initializer.Entity
{
    public class EmployeeRecruitmentStaffEntity
    {
        public int Id { get; set; }
        public string FIRST_NAME { get; set; }
        public string MIDDLE_INITIAL { get; set; }
        public string LAST_NAME { get; set; }
        public string AD_USER_ID { get; set; }
        public string HOME_HDQ { get; set; }
        public string EMAIL { get; set; }
        public string Supervisor_Email { get; set; }
        public CeLocalOfficeStaffEntity CSF { get; set; }
    }
}
