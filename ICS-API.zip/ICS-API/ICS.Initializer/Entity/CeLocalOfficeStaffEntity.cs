﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICS.Initializer.Entity
{
    public class CeLocalOfficeStaffEntity
    {
        public int EMP_RECRUITMENT_STATUS_ID { get; set; }
        public int Id { get; set; }
        public int RECRUITMENT_STATUS_ID { get; set; }
    }
}
