﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICS.Initializer.Helper
{
    public class ConnectionManager : IDisposable
    {
        private readonly string _connection;
        private readonly SqlConnection _client;
        public ConnectionManager()
        {
            _connection = ConfigurationManager.ConnectionStrings["ESConnectionString"].ConnectionString;
            _client = new SqlConnection(_connection);
        }

        public SqlConnection GetSqlConnection()
        {
            return _client;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
