﻿using Dapper;
using ICS.Initializer.Entity;
using ICS.Initializer.Helper;
using ICS.Initializer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICS.Initializer
{
    public class EmployeeStaffRcData
    {
        private readonly string _queryForGet = "select LOS.*,ERS.* from ce_local_office_staff LOS inner join ICS_EMP_RECRUITMENT_STATUS ERS on LOS.Id = ERS.Id where ERS.RECRUITMENT_STATUS_ID = 1 ";
        private readonly ConnectionManager _connection;
        public EmployeeStaffRcData()
        {
            _connection = new ConnectionManager();
        }

        public List<EmployeeStaffRcDetails> GetESRDetails(int statusId)
        {
            var ESR = new List<EmployeeStaffRcDetails>();
            using (var conn = _connection.GetSqlConnection())
            {
                conn.Open();
                var result = conn.Query<EmployeeRecruitmentStaffEntity, CeLocalOfficeStaffEntity, EmployeeRecruitmentStaffEntity>(_queryForGet,
                        (ER, SE) =>
                        {
                            ER.CSF = SE;
                            return ER;
                        }).ToList();

                if (result == null)
                    return ESR;

                result.ToList().ForEach(es =>
                {
                    ESR.Add(new EmployeeStaffRcDetails()
                    {
                        ADID=es.AD_USER_ID,
                        Email= "naga.kolluru@cmsenergy.com'",
                        HomeArea=es.HOME_HDQ,
                        Name=es.FIRST_NAME + "" + es.MIDDLE_INITIAL +"" + es.LAST_NAME,
                        PERNR=es.Id,
                        SupervisorEmail= "chistopher.bills@cmsenergy.com"
                    });
                });
                return ESR;
            }
        }
    }
}
