﻿using ICS.Initializer;
using ICS.Initializer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ICS.Services
{
    public class EmployeeStaffRcService
    {
        private readonly EmployeeStaffRcData _employeeStaffRcData;
        public EmployeeStaffRcService()
        {
            _employeeStaffRcData = new EmployeeStaffRcData();
        }

        public List<EmployeeStaffRcDetails> GetESRDetailsService(int statusId)
        {
            return _employeeStaffRcData.GetESRDetails(statusId);
        }

    }
}
