﻿using ICS.Initializer.Models;
using ICS.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace ICS.WebApi.Controllers
{
   
    public class EmployeeRecruitmentStaffController : ApiController
    {
        private readonly EmployeeStaffRcService _employeeStaffRcService;
        public EmployeeRecruitmentStaffController(EmployeeStaffRcService employeeStaffRcService)
        {
            _employeeStaffRcService = new EmployeeStaffRcService();
        }

        public HttpResponseMessage Get()
        {
            var result = _employeeStaffRcService.GetESRDetailsService(1);

            return new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(result), Encoding.UTF8, "application/json")
            };
        }
    }
}