﻿using ICS.Initializer.Models;
using ICS.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace ICS.WebApi.Controllers
{
    class ERUI
    {
        public List<EmployeeStaffRcDetails> data { get; set; }
    }
    public class EmployeeRecruitmentStaffController : ApiController
    {
        private readonly EmployeeStaffRcService _employeeStaffRcService;
        public EmployeeRecruitmentStaffController(EmployeeStaffRcService employeeStaffRcService)
        {
            _employeeStaffRcService = new EmployeeStaffRcService();
        }
        
        public HttpResponseMessage Get(int id)
        {
            var result = _employeeStaffRcService.GetESRDetailsService(id);
            var response = new ERUI()
            {
                data = result
            };
            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}