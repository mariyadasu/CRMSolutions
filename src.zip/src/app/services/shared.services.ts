import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export class SharedService {
  baseUri:"http://localhost:53398/api/";
  constructor(
    private httpClient : HttpClient
  ) { }

  getEmployeeRecruitmentStaff() : Observable<any>{
    return this.httpClient.get("http://localhost:53398/api/EmployeeRecruitmentStaff/Get");
   
  }


}
