import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/components/common/api';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';

import {SharedService} from '../services/shared.services';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
  providers: [MessageService]
})

export class AdminComponent implements OnInit {
  eligibleAlert: boolean = false;
  summaryAlert: boolean = false;
  assignAlert: boolean = false;
  checked: boolean = false;
  cities: City[];
  teams: Team[];
  data: any;
  date3: Date;
  msgs: Message[] = [];
  labelSet: string[] = [];
  
  selectedAssignments: string[] = [];
  constructor(private messageService: MessageService,
    private sharedService: SharedService) {
 

    //clean up this static content
    this.cities = [
      { name: 'New York', code: 'NY' },
      { name: 'Rome', code: 'RM' },
      { name: 'London', code: 'LDN' },
      { name: 'Istanbul', code: 'IST' },
      { name: 'Paris', code: 'PRS' }
    ];
    this.teams = [
      { name: 'Team1', code: 'T1' },
      { name: 'Team2', code: 'T2' },
      { name: 'Team3', code: 'T3' },
      { name: 'Team4', code: 'T4' },
      { name: 'Team5', code: 'T5' }
    ];
    this.labelSet=[];
    for(let team of this.teams){
      this.labelSet.push(team.name);
     }
    this.data = {
      labels: this.labelSet,
      datasets: [
        {
          label: 'No of Volunteers/Team',
          backgroundColor: '#42A5F5',
          borderColor: '#1E88E5',
          data: [65, 59, 80, 81, 56]
        },
      ]
    }
  }

  inProgressData:any=[];

  ngOnInit() {
    this.getInprogressData();
  }
  getInprogressData(){
    this.sharedService.getEmployeeRecruitmentStaff().subscribe(data=>{
     // let d=JSON.parse(data);
      this.inProgressData=data;
    });
  }
  showEligibleAlert() {
    this.eligibleAlert = true;
  }
  showSummaryAlert() {
    this.summaryAlert = true;
  }
  showAssignAlert() {
    this.assignAlert = true;
  }
  showSuccess(msg:string) {
    this.msgs = [];
    this.msgs.push({ severity: 'success', summary: 'Validate Message', detail: msg });
  }
  showNotSuccess(msg:string) {
    this.msgs = [];
    this.msgs.push({ severity: 'error', summary: 'Validate Message', detail: msg });
  }
}
interface City {
  name: string;
  code: string;
}
interface Team {
  name: string;
  code: string;
}