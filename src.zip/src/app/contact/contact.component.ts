
import { Component, ViewChild } from '@angular/core';
import {Router,RouterModule} from "@angular/router";

@Component({
  selector: 'contact-ics',
  templateUrl: './contact.component.html'
})
export class ContactComponent {
    currentState:string="";
    constructor(public router:Router) {
      
        }
        ngOnInit() {
            this.currentState=this.router.url;
          
          }
}
